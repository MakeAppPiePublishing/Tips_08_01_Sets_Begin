struct Pizza{
    let authenticCheese = ["Bufalo","Fior de late","Gorgonzola","Mozzarella","Parmigiano"]
    let authenticIngredients = ["Basil","Peppers","Tomatoes", "Basil", "Oregano"]
    enum Crust{
        case thin,thick,pan,lavosh,potPie
    }
    var crust : Crust
    var cheeses: [String]
    var toppings: [String]
    
}

let margherita = Pizza(crust: .thin, cheeses: ["Mozzarella"], toppings: ["Basil","Tomatoes","Parmigiano","Oil"])
let margheritaDoc = Pizza(crust: .thin, cheeses: ["Bufala"], toppings: ["Basil","Tomatoes","Parmigiano","Oil"])
let chicago = Pizza(crust: .pan, cheeses: ["Mozzarella"], toppings: ["Pizza Sauce","Sausage"])
let quattroFormaggi = Pizza(crust: .thin, cheeses: ["Fontina","Gorgonzola","Mozzarella","Parmigiano"], toppings: ["Crushed Tomatoes","Basil","Oil"])


let toppings: Set = ["Crushed Tomatoes","Basil","Oil","Chicken","BBQ Sauce","Red Onions","Parmigiano", "Peppernoi","Prociutto","Pineapple","Canadian Bacon"]
